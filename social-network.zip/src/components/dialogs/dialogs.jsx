import React from 'react'
import './dialogs.css'
import spiderman from '../../img/spidey.webp'
import DialogMessage from './dialogMessage/dialogMessage'
import DialogName from './dialogName/dialogName'
function Dialogs() {
    return (
        <div className='dialogs'>
            <div className='dialogs-left'>
                <DialogName name={'Питер Паркер'} id={'1'}></DialogName>
                <DialogName name={'Тор Одинсон'} id={'2'}></DialogName>
                <DialogName name={'Клинт Бартлонт'} id={'3'}></DialogName>
            </div>
            <div className='dialogs-right'>
                <DialogMessage message={'Lorem ipsum dolor sit amet.'}></DialogMessage>
                <DialogMessage message={'Lorem ipsum dolor sit amet.'}></DialogMessage>
                <DialogMessage message={'Lorem ipsum dolor sit amet.'}></DialogMessage>
            </div>
            
            {/* <div className='dialog'>
                <img className='dialog-img' src={spiderman} alt="" />
                <p className='dialog-name'>Питер Паркер</p>
                <p className='dialog-text'>Lorem ipsum dolor sit amet.</p>
            </div>
            <div className='dialog'>
                <img className='dialog-img' src={spiderman} alt="" />
                <p className='dialog-name'>Тор Одинсон</p>
                <p className='dialog-text'>Lorem ipsum dolor sit amet.</p>
            </div>
            <div className='dialog'>
                <img className='dialog-img' src={spiderman} alt="" />
                <p className='dialog-name'>Клинт Бартлонт</p>
                <p className='dialog-text'>Lorem ipsum dolor sit amet.</p>
            </div> */}
        </div>
    )
}


export default Dialogs