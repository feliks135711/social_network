import React from 'react'
import brusBenner from '../../../img/брюс беннер.jpg'
import Post from './post/post'


function Posts() {
    return (

        <div className='posts'>
            <div className='enter-post'>
                <img className='enter-post-img' src={brusBenner} alt="" />
                <div className='enter-post-content'>
                    <input type="text" placeholder='введите комментарий' />
                    <button>отправить</button>
                </div>
            </div>
            <Post name="Брюс Беннер" photo={brusBenner} text="Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam, praesentium sint. Saepe expedita totam quos!" />
            <Post name="Стив Роджерс" photo={brusBenner} text="Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam, praesentium sint. Saepe expedita totam quos!" />
            <Post name="Питер Паркер" photo={brusBenner} text="Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam, praesentium sint. Saepe expedita totam quos!" />
        </div>

    )
}


export default Posts