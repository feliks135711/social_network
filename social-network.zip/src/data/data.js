import { reRenderTree } from "../render"

let data = {
    postsItems :[
        { name: 'Брюс Беннер', photo: '../../../../img/брюс беннер.jpg', text: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam, praesentium sint. Saepe expedita totam quos!', id: 1, likes: 7 },
        { name: 'Стив Роджерс', photo: '../../../../img/брюс беннер.jpg', text: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam, praesentium sint.', id: 2, likes: 5 },
        { name: 'Питер Паркер', photo: '../../../../img/брюс беннер.jpg', text: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit.', id: 3, likes: 15 },
        { name: 'Тони Старк', photo: '../../../../img/брюс беннер.jpg', text: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit.', id: 4, likes: 21 },
    ],

    dialogNames :[
        { name: 'Питер Паркер', id: '1', img:'../../../../img/spidey.webp' },
        { name: 'Тор Одинсон', id: '2', img:'../../../../img/tor.webp' },
        { name: 'Клинт Бартлонт', id: '3', img:'../../../../img/barton.jpg' },
        { name: 'Локи', id: '4', img:'../../../../img/loki.jpeg' },
        { name: 'Стрендж', id: '5', img:'../../../../img/strendg.jpeg' },
    ],

    dialogMessages :[
        { message: 'Lorem ipsum dolor sit amet.', id: '1' },
        { message: 'Lorem ipsum dolor sit amet.', id: '2' },
        { message: 'Lorem ipsum dolor sit amet.', id: '3' },
        { message: 'Lorem ipsum dolor sit amet.', id: '4' },
        { message: 'Lorem ipsum dolor sit amet.', id: '5' },
    ],

    userProfile :[
        {name: 'Тони Старк', img:'../../../../img/тони старк.jpg', birthday:'20.08.2000', hobbi:'технологии, спортивный образ жизни',
            description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse odio autem nesciunt quaerat reiciendis beatae.'
        }
    ],
    newPostText:''
}





export default data
let idPostCounter= data.postsItems.length
export function addPost(postText){
    idPostCounter++
    let newPost = {
        name:'Стивен Стрендж',
        photo:'../../../../img/брюс беннер.jpg',
        text:postText,
        id:idPostCounter,      
        likes:0,
        
    }
    data.postsItems.unshift(newPost)
    reRenderTree(data)
    console.log(data)
}

export function OnPostChange(text){
    data.newPostText=text
    console.log(data)
    reRenderTree(data)
}
